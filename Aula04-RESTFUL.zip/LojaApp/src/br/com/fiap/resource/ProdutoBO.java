package br.com.fiap.resource;

import java.util.List;

import br.com.fiap.resource.dao.ProdutoDAO;
import br.com.fiap.resource.to.ProdutoTO;

public class ProdutoBO {
	public List<ProdutoTO> listagemProduto(){
		ProdutoDAO pd = new ProdutoDAO();
		return pd.select();
	}
	
	public ProdutoTO listagemProduto(int idProduto){
		ProdutoDAO pd = new ProdutoDAO();
		return pd.select(idProduto);
	}
	
	public void cadastrar(ProdutoTO produto) {
		ProdutoDAO pd = new ProdutoDAO();
		pd.insert(produto);
	}
}
